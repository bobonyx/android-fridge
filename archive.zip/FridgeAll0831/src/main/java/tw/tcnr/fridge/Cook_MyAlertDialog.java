package tw.tcnr.fridge;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;


public class Cook_MyAlertDialog extends AlertDialog {
    protected Cook_MyAlertDialog(@NonNull Context context) {
        super(context);
    }
}
